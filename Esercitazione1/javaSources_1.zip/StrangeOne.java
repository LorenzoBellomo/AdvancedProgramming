class StrangeOne
{
    int b0 = 42;
    int b1 = 42;

    int sum ()
    {
        return b0 + b1;
    }
}