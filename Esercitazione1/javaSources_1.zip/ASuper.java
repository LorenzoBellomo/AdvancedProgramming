class ASuper
{
    void foo () { System.out.println("ASuper"); }
    void bar () { foo(); }
}