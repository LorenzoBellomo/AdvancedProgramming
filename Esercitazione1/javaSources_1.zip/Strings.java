class Strings1
{
	public static void main (String... args)
	{
		while (true)
		{
			int i = 9;
			System.out.print("Result = ");
			System.out.println(i);
		}
    }
}

class Strings2
{
	public static void main (String... args)
	{
		while (true)
		{
			int i = 9;
			System.out.println("Result = " + i);
		}
    }
}
