class BSub extends ASuper
{
    void foo () { System.out.println("BSub"); }
    void tee () { foo(); }
}