class StrangeTwo
{
    byte b0 = 42;
    byte b1 = 42;

    int sum ()
    {
        return b0 + b1;
    }
}